import tkinter as tk
from tkinter import messagebox, font
import json
import os
import sys

# Determine the absolute path of the directory containing the script/EXE
if getattr(sys, 'frozen', False):
    # If the application is run as a PyInstaller EXE
    application_path = os.path.dirname(sys.executable)
else:
    # If the application is run from a Python script
    application_path = os.path.dirname(os.path.abspath(__file__))

# Lock the config file path directly next to the EXE
CONFIG_FILE = os.path.join(application_path, "config.json")

def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {"api_key": "", "model_translate": "deepseek-chat", "prompt_translate": ""}

def save_config(data):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def on_save():
    new_config = {
        "api_key": entry_api.get().strip(),
        "model_translate": entry_model.get().strip(),
        "prompt_translate": text_prompt.get("1.0", "end-1c")
    }
    try:
        save_config(new_config)
        messagebox.showinfo(
            "Success", 
            "Configuration successfully saved to config.json!\n\n"
            "Thanks to the hot-reload mechanism, the background service "
            "has been automatically refreshed. No manual restart required."
        )
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred:\n{str(e)}")

# Initialize main window
root = tk.Tk()
root.title("Translation Settings Configuration")
root.geometry("650x550")
root.configure(padx=20, pady=20)

# Set fonts
default_font = font.Font(family="Arial", size=10)
bold_font = font.Font(family="Arial", size=10, weight="bold")
root.option_add("*Font", default_font)

config_data = load_config()

# --- API Key Section ---
tk.Label(root, text="API Key:", font=bold_font).pack(anchor="w", pady=(0, 5))
entry_api = tk.Entry(root, width=50)
entry_api.pack(fill="x", pady=(0, 15))
entry_api.insert(0, config_data.get("api_key", ""))

# --- Model Selection Section ---
tk.Label(root, text="Target Model:", font=bold_font).pack(anchor="w", pady=(0, 5))
entry_model = tk.Entry(root, width=50)
entry_model.pack(fill="x", pady=(0, 15))
entry_model.insert(0, config_data.get("model_translate", "deepseek-chat"))

# --- Prompt Section ---
tk.Label(root, text="System Prompt:", font=bold_font).pack(anchor="w", pady=(0, 5))
text_prompt = tk.Text(root, height=15, wrap="word", padx=10, pady=10)
text_prompt.pack(fill="both", expand=True, pady=(0, 15))
text_prompt.insert("1.0", config_data.get("prompt_translate", ""))

# --- Save Button ---
btn_save = tk.Button(
    root, 
    text="Save and Auto-Reload Configuration", 
    command=on_save, 
    bg="#28a745", 
    fg="white", 
    font=("Arial", 11, "bold"),
    pady=5
)
btn_save.pack(fill="x")

# Center window logic
root.update_idletasks()
width = root.winfo_width()
height = root.winfo_height()
x = (root.winfo_screenwidth() // 2) - (width // 2)
y = (root.winfo_screenheight() // 2) - (height // 2)
root.geometry(f'{width}x{height}+{x}+{y}')

root.mainloop()
