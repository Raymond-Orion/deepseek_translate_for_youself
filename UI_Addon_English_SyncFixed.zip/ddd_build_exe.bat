@echo off
title Build UI to EXE
color 0b

echo ==============================================================================
echo                 Packaging the Settings UI into a standalone EXE
echo ==============================================================================
echo.
echo [INFO] Calling PyInstaller for console-less compilation...
echo.

pyinstaller --noconsole --onefile --windowed --name "Settings_UI" settings_ui.py

echo.
echo ==============================================================================
echo [DONE] Build Complete!
echo ==============================================================================
echo Your EXE file has been generated in the "dist" folder in the current directory.
echo Filename: Settings_UI.exe
echo You can copy this EXE file to your project root or share it with others.
echo ==============================================================================
pause
